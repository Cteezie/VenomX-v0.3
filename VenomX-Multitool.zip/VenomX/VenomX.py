import os
import time
import colorama
import webbrowser
from colorama import Fore
colorama.init()

color_1 = Fore.BLUE
color_2 = Fore.RED
color_3 = Fore.LIGHTCYAN_EX
color_4 = Fore.MAGENTA
color_5 = Fore.LIGHTBLUE_EX
color_6 = Fore.CYAN
color_7 = Fore.LIGHTMAGENTA_EX

Main_logo = f"""

{color_1} ██▒   █▓▓█████  ███▄    █  ▒█████   ███▄ ▄███▓▒██   ██▒
{color_1}▓██░   █▒▓█   ▀  ██ ▀█   █ ▒██▒  ██▒▓██▒▀█▀ ██▒▒▒ █ █ ▒░
{color_5} ▓██  █▒░▒███   ▓██  ▀█ ██▒▒██░  ██▒▓██    ▓██░░░  █   ░
{color_5}  ▒██ █░░▒▓█  ▄ ▓██▒  ▐▌██▒▒██   ██░▒██    ▒██  ░ █ █ ▒ 
{color_4}   ▒▀█░  ░▒████▒▒██░   ▓██░░ ████▓▒░▒██▒   ░██▒▒██▒ ▒██▒
{color_4}  ░ ▐░  ░░ ▒░ ░░ ▒░   ▒ ▒ ░ ▒░▒░▒░ ░ ▒░   ░  ░▒▒ ░ ░▓ ░
{color_4}   ░ ░░   ░ ░  ░░ ░░   ░ ▒░  ░ ▒ ▒░ ░  ░      ░░░   ░▒ ░                    
{color_7}     ░░     ░      ░   ░ ░ ░ ░ ░ ▒  ░      ░    ░    ░  
{color_7}       ░     ░  ░         ░     ░ ░         ░   VenomX               
{color_7}      ░                                                  
"""

Main_Hub = f"""
{color_7}[+]================[+]================[+]===============[+]
{color_7} |{color_1} [1] pingers      {color_7}|{color_1} [6] Proxy Scan   {color_7}|{color_1} [11] PuTTy      {color_7}|
{color_7} |{color_1} [2] ip lookup    {color_7}|{color_1} [7] Check host   {color_7}|{color_1} [12] Vpn        {color_7}|
{color_7} |{color_1} [3] ddos programs{color_7}|{color_1} [8] Free stresser{color_7}|{color_1} [13] ascii ART  {color_7}|
{color_7} |{color_1} [4] LucidREaps   {color_7}|{color_1} [9] password gen {color_7}|{color_1} [14] patorjk.com{color_7}|
{color_7} |{color_1} [5] Virus builder{color_7}|{color_1} [10] IP saver    {color_7}|{color_1} [15] Exit       {color_7}|
{color_7}[+]================[+]================[+]===============[+]
"""

def Main():
    os.system('cls')
    print(Main_logo)
    print(Main_Hub)
    choice = input ('Venomx@666.com#> ')
    if choice == '1':
        os.startfile('Pingers.bat')
        Main()
    if choice == '2':
        os.startfile('iplookup.exe')
        Main()
    if choice == '3':
        os.startfile('cc.exe')
        Main()
    if choice == '4':
        os.startfile('lucidreaps.exe')
        Main()
    if choice == '5':
        os.startfile('Virus Maker.exe')
        Main()
    if choice == '6':
        os.startfile('pscan.exe')
        Main()
    if choice == '7':
        webbrowser.open("https://check-host.net/?lang=en&__cf_chl_managed_tk__=pmd_8p_waTbBSdSCfMKUEcUe2Iahb0jz..DJVonyVdAb1B4-1631577890-0-gqNtZGzNArujcnBszRHR")
        Main()
    if choice == '8':
        webbrowser.open("https://freestresser.to/")
        Main()
    if choice == '9':
        os.startfile('passwordgen.bat')
        Main()
    if choice == '10':
        os.startfile('SaveIP.bat')
        Main()
    if choice == '11':
        os.startfile('PuTTy.exe')
        Main()
    if choice == '12':
        webbrowser.open("https://courvix.com/vpn.php")
        Main()
    if choice == '13':
        webbrowser.open("http://patorjk.com/software/taag/#p=display&f=Big&t=Hey%20you%20fuck%20off!")
        Main()
    if choice == '14':
        webbrowser.open("https://fsymbols.com/text-art/")
        Main()
    if choice == '15':
        print("Exiting the Holocaust")
        time.sleep(1)
        sys.ext(0)

    else:
        print('invalid input!')
        time.sleep(2)
        Main()

Main()